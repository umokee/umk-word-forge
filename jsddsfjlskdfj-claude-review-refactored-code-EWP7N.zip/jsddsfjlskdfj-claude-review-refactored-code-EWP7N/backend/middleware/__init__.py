"""
Middleware package - Authentication and request/response processing
"""
