"""
Penalties module - Penalty calculation and management.
"""

from .service import PenaltyService

__all__ = [
    "PenaltyService",
]
