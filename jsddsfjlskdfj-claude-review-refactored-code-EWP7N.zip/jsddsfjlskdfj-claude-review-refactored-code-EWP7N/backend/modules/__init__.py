"""
Business modules package.
Each module is a self-contained business area.
"""
