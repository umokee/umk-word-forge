"""
Scripts package - Utility scripts for database management and migrations
"""
