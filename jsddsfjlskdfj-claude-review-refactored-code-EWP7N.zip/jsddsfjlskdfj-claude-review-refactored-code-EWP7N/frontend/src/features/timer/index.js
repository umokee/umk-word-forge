/**
 * Timer feature exports.
 */
export { default as Timer } from './components/Timer';
