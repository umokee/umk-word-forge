/**
 * Goals feature exports.
 */
export { default as PointsGoals } from './components/PointsGoals';
export { useGoals } from './hooks/useGoals';
