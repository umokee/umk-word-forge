/**
 * Settings feature exports.
 */
export { default as Settings } from './components/Settings';
export { useRestDays } from './hooks/useRestDays';
